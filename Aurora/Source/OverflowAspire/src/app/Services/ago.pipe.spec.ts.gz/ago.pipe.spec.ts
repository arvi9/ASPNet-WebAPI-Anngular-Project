import { AgoPipe } from './ago.pipe';

describe('AgoPipe', () => {
  it('create an instance', () => {
    const pipe = new AgoPipe();
    expect(pipe).toBeTruthy();
  });
});
