export class Query {
    querytitle:string='';
    query:string='';
}
export class QueryComment{
    comment:string='';
    coding:string='';
   
}
export class user{
    id!:number;
    name:string='';
    


}